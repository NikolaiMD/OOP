window.onload = function(){
  var div = document.querySelector('.first');
  div.onclick = function(){
    this.classList.toggle('second');
  }
}
