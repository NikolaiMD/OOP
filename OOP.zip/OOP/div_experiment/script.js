var div = {
  class:"second",
  style:{
    width: 200,
    height: 200,
    background_color: "green",
    border_radius: 100
  },
  show: function(){
    document.write(`<div style="width:${div.style.width}px;
                    height:${div.style.height}px;
                    background-color:${div.style.background_color};
                    border-radius:${div.style.border_radius}%" id="${div.class}"></div>`);
  }
}
