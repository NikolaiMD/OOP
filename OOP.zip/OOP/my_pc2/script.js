var sound_output={sound: 5.1}
var display={
  monitor:{
      manufacturer: "lg",
      inches: 24,
      resolution:{
        width: 1080,
        height: 1920
      },
      interface:{
        hdmi: true,
        vga: true,
        displayPort: true,
        dvi: false
      }
    }
  }
var input={
    keyboard: "genius",
    mouse: "a4tech"
  }
var machine={
    case:{
      manufacturer: "deepCool",
      form_factor: "ATX",
      psu: false
    },
    motherboard:{
      manufacturer: "MSI",
      chipset: "am4",
      m2: true,
      lights: true,
      sli_support: true,
      overclocking_support: true
    },
    cpu:{
      manufacturer: "amd",
      model: {
        name:"ryzen5",
        abbreviation: 1600
      },
      cores: 6,
      threads: 12,
      frequency: 3200,
      unlocked: true
    },
    graphics_card:{
      manufacturer: "zotac",
      gpu: "nvidia",
      model: 1060,
      memory: 6,
      active_cooling: true
    },
    ram:{
      manufacturer: "corsair",
      model: "rgb",
      frequency: 3200,
      memory: 16
    },
    storage:{
      form_factor: "m2",
      type: "nvme",
      memory: 520
    },
    psu:{
      manufacturer: "deepCool",
      power: 500
    }
  }
var my_pc={
  sound_system: sound_output,
  display_system: display,
  input_system: input,
  system_block: machine
}
